CREATE PROCEDURE TSQLclass
AS
SELECT FacultyName from FACULTY f inner join STUDENT d
on
f.FacultyCode = d.StudentCode
go

